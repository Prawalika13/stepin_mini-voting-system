# Implementation

## Folder Structure
Folder        | description
--------------| ----------------------------------------------
`inc`         | All header files
`src`         | Main source code for calculator
`test`        | All source code and data for testing purposes
`build`       | Build output (Not included in git)
